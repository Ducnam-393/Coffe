/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package caffee;
import code.Dao;
import java.awt.Color;
import java.awt.Component;
import java.awt.Image;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
/**
 *
 * @author Hello
 */
public class Tat_Ca_San_Pham extends javax.swing.JFrame {

     /**
      * Creates new form Tat_Ca_San_Pham
      */
     int xx , xy;
     Dao dao = new Dao();
     DefaultTableModel model ;
     
        public Tat_Ca_San_Pham() {
          initComponents();
         bangSanPham();
     }

     private void bangSanPham() {
          dao.getTatCaSanPham(jTable1);
          model = (DefaultTableModel) jTable1.getModel();
          jTable1.setRowHeight(100);
          jTable1.setShowGrid(true);
          jTable1.setGridColor(Color.BLACK);
          jTable1.setBackground(Color.WHITE);
          jTable1.setSelectionBackground(Color.gray);
          jTable1.setModel(model);
          jTable1.getTableHeader().setReorderingAllowed(false);
          jTable1.getColumnModel().getColumn(3).setCellRenderer(new Tat_Ca_San_Pham.imageRederer());
     } 
     @SuppressWarnings("unchecked")
     // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
     private void initComponents() {

          jPanel1 = new javax.swing.JPanel();
          jLabel4 = new javax.swing.JLabel();
          jScrollPane1 = new javax.swing.JScrollPane();
          jTable1 = new javax.swing.JTable();
          jLabel1 = new javax.swing.JLabel();

          setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
          setUndecorated(true);
          addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
               public void mouseDragged(java.awt.event.MouseEvent evt) {
                    formMouseDragged(evt);
               }
          });
          addMouseListener(new java.awt.event.MouseAdapter() {
               public void mousePressed(java.awt.event.MouseEvent evt) {
                    formMousePressed(evt);
               }
          });
          addWindowListener(new java.awt.event.WindowAdapter() {
               public void windowOpened(java.awt.event.WindowEvent evt) {
                    formWindowOpened(evt);
               }
          });

          jPanel1.setBackground(new java.awt.Color(158, 111, 78));

          jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
          jLabel4.setForeground(new java.awt.Color(255, 255, 255));
          jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
          jLabel4.setText("X");
          jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
               public void mouseClicked(java.awt.event.MouseEvent evt) {
                    jLabel4MouseClicked(evt);
               }
          });

          jTable1.setModel(new javax.swing.table.DefaultTableModel(
               new Object [][] {

               },
               new String [] {
                    "Mã Sản Phẩm", "Tên Sản Phẩm", "Giá tiền", "Ảnh Sản Phẩm"
               }
          ));
          jScrollPane1.setViewportView(jTable1);

          jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
          jLabel1.setForeground(new java.awt.Color(255, 255, 0));
          jLabel1.setText("MENU : NHẬT NAM COFE");

          javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
          jPanel1.setLayout(jPanel1Layout);
          jPanel1Layout.setHorizontalGroup(
               jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
               .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                         .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                              .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                              .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 493, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addGap(168, 168, 168)
                              .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                         .addGroup(jPanel1Layout.createSequentialGroup()
                              .addGap(78, 78, 78)
                              .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 733, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addGap(0, 83, Short.MAX_VALUE)))
                    .addContainerGap())
          );
          jPanel1Layout.setVerticalGroup(
               jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
               .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                         .addGroup(jPanel1Layout.createSequentialGroup()
                              .addContainerGap()
                              .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                         .addGroup(jPanel1Layout.createSequentialGroup()
                              .addGap(16, 16, 16)
                              .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGap(34, 34, 34)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 456, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(67, Short.MAX_VALUE))
          );

          javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
          getContentPane().setLayout(layout);
          layout.setHorizontalGroup(
               layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
               .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
          );
          layout.setVerticalGroup(
               layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
               .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
          );

          pack();
          setLocationRelativeTo(null);
     }// </editor-fold>//GEN-END:initComponents

     private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
          // TODO add your handling code here:
          setVisible(false);
     }//GEN-LAST:event_jLabel4MouseClicked

     private void formMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMousePressed
          // TODO add your handling code here:
          xx = evt.getX();
          xy = evt.getY(); 
     }//GEN-LAST:event_formMousePressed

     private void formMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseDragged
          // TODO add your handling code here:
          int x = evt.getXOnScreen();
          int y = evt.getYOnScreen();
          this.setLocation(x - xx, y - xy);  
     }//GEN-LAST:event_formMouseDragged

     private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
          // TODO add your handling code here:
          for (double i = 0.1; i < 1.0; i += 0.1) {
               String s = "" + i;
               float f = Float.parseFloat(s);
               this.setOpacity(f);
               try {                                     
                    Thread.sleep(40);
               } catch (InterruptedException ex) {
                    Logger.getLogger(Tat_Ca_San_Pham.class.getName()).log(Level.SEVERE, null, ex);
               }
     }
     }//GEN-LAST:event_formWindowOpened

        
     private class imageRederer extends DefaultTableCellRenderer{

          @Override
          public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
               JLabel jL = new JLabel();
               byte[] bytes = (byte[]) value;
               ImageIcon imageicon = new ImageIcon(new ImageIcon(bytes).getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT));
               jL.setIcon(imageicon);                           
               return jL;
         
     } 
     
     
    
}   
     /**
      * @param args the command line arguments
      */
     public static void main(String args[]) {
          /* Set the Nimbus look and feel */
          //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
          /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
           */
          try {
               for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                         javax.swing.UIManager.setLookAndFeel(info.getClassName());
                         break;
                    }
               }
          } catch (ClassNotFoundException ex) {
               java.util.logging.Logger.getLogger(Tat_Ca_San_Pham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
          } catch (InstantiationException ex) {
               java.util.logging.Logger.getLogger(Tat_Ca_San_Pham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
          } catch (IllegalAccessException ex) {
               java.util.logging.Logger.getLogger(Tat_Ca_San_Pham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
          } catch (javax.swing.UnsupportedLookAndFeelException ex) {
               java.util.logging.Logger.getLogger(Tat_Ca_San_Pham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
          }
          //</editor-fold>

          /* Create and display the form */
          java.awt.EventQueue.invokeLater(new Runnable() {
               public void run() {
                    new Tat_Ca_San_Pham().setVisible(true);
               }
          });
     }

     // Variables declaration - do not modify//GEN-BEGIN:variables
     private javax.swing.JLabel jLabel1;
     private javax.swing.JLabel jLabel4;
     private javax.swing.JPanel jPanel1;
     private javax.swing.JScrollPane jScrollPane1;
     private javax.swing.JTable jTable1;
     // End of variables declaration//GEN-END:variables
     }
